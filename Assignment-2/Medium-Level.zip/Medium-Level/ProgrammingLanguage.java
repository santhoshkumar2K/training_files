public class ProgrammingLanguage
{
  public void usage()
  {
    System.out.println("It is used to communicate with system.");
  }
 public static void main(String [] args)
 {
   
 }
}
class Java extends ProgrammingLanguage
{
  public void usage()
  {
     System.out.println("It is used to communicate with.");
  }
}
class C extends ProgrammingLanguage
{

}  
